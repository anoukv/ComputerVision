The fundamental matrix demo is fundamentalMatrixDemo.m
To run the chaining, you can call chainingScript.m

