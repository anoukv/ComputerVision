function [  ] = plotSurface( data1 )

plot3(data1(1,:),data1(2,:),data1(3,:),'bo');
axis equal

end

