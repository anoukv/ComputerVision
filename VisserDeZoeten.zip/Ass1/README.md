To merge consecutive frames, call merge1(stepsize, numberOfImage, pathToFileWithData, samplingMethod). 
The sampling method can for example be 'uniform'.
To merge iteratively, call merge2(...) (takes the same arguments as merge1(...)
