We were not able to implement a dense-enough point-view matrix, however we have created a proof-of-concept script proofOfConcept.m

